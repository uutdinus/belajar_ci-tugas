<?= $this->extend('/cart/components/layout') ?>
<?= $this->section('content') ?>


<?= $this->endSection() ?>