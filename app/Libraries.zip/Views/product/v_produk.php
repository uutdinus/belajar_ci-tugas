<?= $this->extend('/product/components/layout') ?>
<?= $this->section('content') ?>


<?= $this->endSection() ?>