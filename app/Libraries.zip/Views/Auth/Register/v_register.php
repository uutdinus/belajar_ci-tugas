<?= $this->extend('/Auth/Register/components/layout') ?>
<?= $this->section('content') ?>


<?= $this->endSection() ?>