<?= $this->extend('/home/components/layout') ?>
<?= $this->section('content') ?>


<?= $this->endSection() ?>